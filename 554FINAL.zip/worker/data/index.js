const MovieData = require("./movie");
const userData = require('./user');

module.exports = {
    movie: MovieData,
    user: userData
};